import java.io.*;
import java.util.*;

public class Character {
    SortedMap<String,MoveTraits> moves = new TreeMap<String, MoveTraits>();
   public Character(String characterData){
       try { 
			
       String fileName = characterData + ".txt";
       BufferedReader br = new BufferedReader(new FileReader(fileName));
       String line = br.readLine();
       
       //data we want to remember
        int[] data = new int[4]; //data will have Level, Startup, Active, Recovery. Frame adv, will be calculated after
        String moveName = "";
        boolean specNor = false; //normal = false, special = true;
        int level;
       while (line != null){
           String[] dataArray = line.split("\t");
           if (dataArray[0].equals("Special")){
               specNor = true;
           }
           
           while (dataArray.length <= 3 || dataArray[0].equals("Name")){
               line = br.readLine();
              if (dataArray[0].equals("Special")){
                specNor = true;
                }
               if (line == null){
                   break;
               }
               dataArray = line.split("\t");
           }
           moveName = dataArray[0];
           data[0] = changeInt(dataArray[7]);
           data[1] = changeInt(dataArray[9]);
           data[2] = changeInt(dataArray[10]);
           data[3] = changeInt(dataArray[11]);
      
           MoveTraits characteristics = new MoveTraits(characterData, moveName, data, specNor); //calls the constructor
           moves.put(moveName, characteristics);
         
           line = br.readLine();
       }

     } catch (Exception e) {
       System.err.println("CSV file cannot be read : " + e);
     }
   }
   public static int changeInt(String move){ //Changes a data to int
         move = move.replace(" ", "");
        move = move.replace("\"", "");
        int loader = 0;
        try{
            loader = Integer.parseInt(move);
        }catch(NumberFormatException e){
            return 0;
        }
       return loader;
   }
   public void showData(){
       Set s = moves.entrySet();
       Iterator it = s.iterator();
       while(it.hasNext()){
             Map.Entry m =(Map.Entry)it.next();

            // getKey is used to get key of Map
            String key=(String)m.getKey();

            // getValue is used to get value of key in Map
            MoveTraits value=(MoveTraits)m.getValue();

            System.out.println("Key :" + key + "\n Value:");
            value.showData();
       }
   }
   public void showMovesOnly(){
         Set s = moves.entrySet();
       Iterator it = s.iterator();
       while(it.hasNext()){
             Map.Entry m =(Map.Entry)it.next();

            // getKey is used to get key of Map
            String key=(String)m.getKey();

            System.out.println( key );
   }
   }
   public boolean checkMoveExist(String move){
       return moves.containsKey(move);
}
   public int calculateHitStun(String opponentMove){
       try{String fileName = "LevelData.txt";
       BufferedReader br = new BufferedReader(new FileReader(fileName));
       String line = "";
       
       for(int i = 0; i < 8; i++){
           line = br.readLine();
       }
       String[] tempString = line.split("\t");
      MoveTraits temporary = moves.get(opponentMove);
      int level = temporary.returnLevel();
       br.close();
      return Integer.parseInt(tempString[level+1]);
       }
       catch(Exception e){
           System.err.println("Derp!");
       }
            return 0;
   }
   
   public int getStartup(String move){
       MoveTraits temporary = moves.get(move);
       return temporary.returnStartup();
   }
   public boolean getSpecial(String move){
       MoveTraits temporary = moves.get(move);
       return temporary.returnSpecial();
   }
   public int getRecovery(String move){
       MoveTraits temporary = moves.get(move);
       return temporary.returnRecovery();
   }
   public int getActive(String move){
       MoveTraits temporary = moves.get(move);
       return temporary.returnActive();
   }
   public void finalCalc(int hitStun, int activeFrames, int oppRecovery, int additional){
       
       Set s = moves.entrySet();
       Iterator it = s.iterator();
       while(it.hasNext()){
           int totalFrames = 0;
             Map.Entry m =(Map.Entry)it.next();

            // getKey is used to get key of Map
            String key=(String)m.getKey();
            MoveTraits temporary = (MoveTraits) m.getValue();
            totalFrames = (hitStun * -1) + additional + activeFrames + (-1 * temporary.returnStartup()) + oppRecovery; //calculates if the opponent just stands there.
           
            if (totalFrames >= 0){
                
                System.out.print("\t" + key+ " (" + (totalFrames + temporary.returnStartup()) + "," + temporary.returnStartup() + ")");
                System.out.println();
            }
           
            
       }
   }
   
   public ArrayList<String> returnCancelability(String opponentMove) {
        Set s = moves.entrySet();
        Iterator it = s.iterator();
        while (it.hasNext()) {
            int totalFrames = 0;
            Map.Entry m = (Map.Entry) it.next();

            // getKey is used to get key of Map
            String key = (String) m.getKey();
            if (key.equals(opponentMove)) {
           
                MoveTraits temporary = (MoveTraits) m.getValue();
                ArrayList<String> tempArrayList = temporary.returnMoveCancel();
                
                return tempArrayList;
            }
        }
        System.out.println("Could not find the move!");
        return null;
    }

  
}



