
import java.io.*;
import java.util.*;

public class main {

    private static String[] names = {"Ragna", "Jin", "Noel", "Rachel", "Taokaka", "Carl", "Litchi", "Arakune", "Tager", "Bang", "Lambda", "Hakumen", "Hazama", "Tsubaki", "Mu-12", "Makoto", "Valkenhayn", "Platinum", "Relius"};
    public static Scanner in = new Scanner(System.in);
    private static Character CharacterA, CharacterB;
    private static String opponentMove = "";
    private static boolean[] conditions = new boolean[6]; //conditions: stand, crouch, air, barrier, instant, wiff
    private static int[] conditionsAdded = {0, 2, 2, 1, -3, 0}; //note: negative is in CharacterA's favor.
    //{"Standing", "Crouching", "Air", "Barrier", "Instant", "Wiff"};

    public static void main(String[] args) {
        double command = -99;
        while (command != 7) {
            menu();
            command = in.nextDouble();
            if (command == 1) {
                Scanner input = new Scanner(System.in);
                int char1, char2;
                for (int i = 0; i < names.length; i++){
                
                    System.out.println((i+1) + ")" + names[i]);
                }
                System.out.println("Enter your character: ");
                char1 = input.nextInt();
                System.out.print("Enter opponent character: ");
                char2 = input.nextInt();
                CharacterA = new Character(names[char1-1]);
                CharacterB = new Character(names[char2-1]);
            }
            if (command == 2) {
                displayAllData();
            }
            if (command == 4) {
                opponentMoveSet();
            }
            if (command == 5) {
                conditions();
            }
            if (command == 6) {
                comparison();
            }
        }
    }

    public static void displayAllData() {
        CharacterA.showData();
        CharacterB.showData();
    }

    public static void opponentMoveSet() {
        Scanner input = new Scanner(System.in);
        CharacterB.showMovesOnly();
        System.out.println("Please select your opponent's move");
        opponentMove = input.nextLine();
        while (!CharacterB.checkMoveExist(opponentMove)) {
            System.out.println("Move not found!");
            opponentMove = input.nextLine();
        }

    }

    public static void menu() {
        String[] menuOptions = {"Load Characters", "Display Raw Data", "Display Data For 1 Move", "Select Opponent's Moves", "Input Conditions", "Show comparison data", "Quit"};
        for (int i = 0; i < menuOptions.length; i++) {
            System.out.println(i + 1 + ") " + menuOptions[i]);
        }
    }

    public static void conditions() {
        for (int j = 0; j < conditions.length; j++) {
            conditions[j] = false;
        }
        String[] conditionNames = {"Standing", "Crouching", "Air", "Barrier", "Instant", "Wiff"}; //stand, crouch, air, barrier, instant, wiff
        Scanner input = new Scanner(System.in);
        for (int i = 0; i < conditionNames.length; i++) {
            System.out.println((i + 1) + ") " + conditionNames[i]);
        }
        String inputConditions;
        inputConditions = input.nextLine();

        String[] choices = inputConditions.split(",");
        for (int i = 0; i < conditions.length; i++) {
            for (int j = 0; j < choices.length; j++) {
                if (i == (Integer.parseInt(choices[j]) - 1)) {
                    conditions[i] = true;
                }
            }
        }
        System.out.println("Conditions set!");
    }

    public static void noCanceling(int hitStun, int activeFrames, int oppRecovery, int additional) {
        CharacterA.finalCalc(hitStun, activeFrames, oppRecovery, additional);
    }

    public static void canceling(int hitStun, int activeFrames, int oppRecovery, int additional) {

        ArrayList<String> moveCancels = CharacterB.returnCancelability(opponentMove);

        for (int i = 0; i < moveCancels.size(); i++) { //iterates through all the cancel 

            if (moveCancels.get(i).equals("Special")) { //spits out special attacks
                //want to get all the special moves and interate through them
                SortedMap<String, MoveTraits> specialMoves = new TreeMap<String, MoveTraits>();


                Set s = CharacterB.moves.entrySet();
                Iterator it = s.iterator();
                while (it.hasNext()) {
                    int totalFrames = 0;
                    Map.Entry m = (Map.Entry) it.next();

                    // getKey is used to get key of Map
                    String key = (String) m.getKey();
                    if (CharacterB.getSpecial(key)) {
                        int opponentStartup = CharacterB.getStartup(key);
                        System.out.println("Opponent's move: " + key);
                        System.out.println("\tStartup: " + opponentStartup);
                        // CharacterA.finalCalc(hitStun, activeFrames, opponentStartup, additional); (Still up for debate as a viable function)
                        CharacterA.finalCalc(hitStun, activeFrames, opponentStartup, additional);
                        System.out.println();
                    }
                }
            }

            if (CharacterB.checkMoveExist(moveCancels.get(i))) {
                System.out.println(moveCancels.get(i));
                int opponentStartup = CharacterB.getStartup(moveCancels.get(i));


                System.out.println("\tStartup: " + opponentStartup);
                // CharacterA.finalCalc(hitStun, activeFrames, opponentStartup, additional); (Still up for debate as a viable function)
                
                CharacterA.finalCalc(hitStun, 0, opponentStartup, additional);
                System.out.println();
            }
        }
    }

    public static void comparison() {
        int hitStun = CharacterB.calculateHitStun(opponentMove);
        int oppRecovery = CharacterA.getRecovery(opponentMove);
        int additional = calculateAdditionalConditions();
        int activeFrames = CharacterB.getActive(opponentMove);
        System.out.println("If the opponent does not cancel");
        noCanceling(hitStun, activeFrames, oppRecovery, additional);

        System.out.println();
        System.out.println("If the opponent does cancel: ");
        canceling(hitStun, activeFrames, oppRecovery, additional);

        /*
         * for(int i = 0; i < moveCancels.size(); i++){
         *
         * String opponentNextMove = moveCancels.get(i); * int opponentStartup =
         * CharacterB.getStartup(opponentNextMove);
         * CharacterA.finalCalc(hitStun, activeFrames, opponentStartup,
         * additional); }
         *
         */
    }

    public static int calculateAdditionalConditions() {
        int additional = 0;
        for (int i = 0; i < conditions.length; i++) {
            if (conditions[i] == true) {

                additional -= (conditionsAdded[i]);
            }
            if (conditions[2] && conditions[4]) { //instant air block
                additional -= 4;
            }
        }
        System.out.println(additional);
        return additional;
    }
}
